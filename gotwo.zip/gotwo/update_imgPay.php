<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php");

//-------------------------------------------------------

$status_post_id = intval($_POST['status_post_id']);
$imgPay = $_POST['imgPay'];
//-------------------------------------------------------

$update_sql = "UPDATE `status_post` SET `image` = '$imgPay'  WHERE `status_post_id` = '$status_post_id';";

if ($conn->query($update_sql)) {
    echo "Update Success";
} else {
    echo "Error updating post!";
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();

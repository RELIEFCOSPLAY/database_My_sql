<?php
require_once("qr_code/PromptPayQR.php");
$PromptPayQR = new PromptPayQR(); // new object

$price = intval($_POST['price']);
$promptPay = $_POST['promptPay'];
$action = $_POST['action'];

if ($action == "PAY") {
    $PromptPayQR->size = 8; // Set QR code size to 8
    $PromptPayQR->id = $promptPay; // PromptPay ID
    $PromptPayQR->amount = $price; // Set amount

    // Generate QR image as a temporary file
    $tempFilePath = tempnam(sys_get_temp_dir(), 'qrcode') . '.png';
    $PromptPayQR->generate($tempFilePath);

    // Read file content and encode to base64
    $imageData = file_get_contents($tempFilePath);
    $base64 = base64_encode($imageData);

    // Remove temporary file
    unlink($tempFilePath);

    // Send JSON response with base64 image data
    echo json_encode([
        "status" => "success",
        "qr_code" => $base64
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
}

<?php
include("config.php"); // เชื่อมต่อฐานข้อมูล

$email = $_POST['email'];
$password = $_POST['password']; // รหัสผ่านที่แฮชจาก Flutter

// ค้นหาผู้ใช้
$sql = "SELECT * FROM table_rider WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $storedPasswordHash = $row['password']; // รหัสผ่านที่แฮชในฐานข้อมูล
    $statusRider = $row['status_rider']; // เพิ่มการดึงค่า status_rider

    if (password_verify($password, $storedPasswordHash)) { // เปรียบเทียบรหัสผ่านที่แฮช
        echo json_encode([
            "status" => "Success",
            "status_rider" => $statusRider, // ส่งค่า status_rider กลับไป
        ]);
    } else {
        echo json_encode([
            "status" => "Error",
            "message" => "Incorrect password."
        ]);
    }
} else {
    echo json_encode([
        "status" => "Error",
        "message" => "Email not found."
    ]);
}

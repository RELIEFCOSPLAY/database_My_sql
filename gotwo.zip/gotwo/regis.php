<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php");

if (isset($_POST['img_profile'], $_POST['name'], $_POST['email'], $_POST['tel'], $_POST['gender'], $_POST['password'], $_POST['img_id_card'], $_POST['bank'], $_POST['name_account'], $_POST['number_bank'], $_POST['status_customer'])) {
    $img_profile = $_POST['img_profile'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $gender = $_POST['gender'];
    $password = intval($_POST['password']);
    $img_id_card = $_POST['img_id_card'];
    $bank = $_POST['bank'];
    $name_account = $_POST['name_account'];
    $number_bank = intval($_POST['number_bank']);
    $status_customer = intval($_POST['status_customer']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    // ใช้ Prepared Statement เพื่อป้องกัน SQL Injection
    $stmt = $conn->prepare("INSERT INTO `table_customer` 
        (`img_profile`, `name`, `email`, `tel`, `gender`, `password`, `img_id_card`, `bank`, `name_account`, `number_bank`, `status_customer`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // ผูกค่าที่ได้รับจาก Flutter เข้ากับ Query
    $stmt->bind_param("ssssssssssi", $img_profile, $name, $email, $tel, $gender, $hashed_password, $img_id_card, $bank, $name_account, $number_bank, $status_customer);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Data inserted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid input data"]);
}

$conn->close();

<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php");

// รับค่าที่ส่งมาจาก Flutter
$img_profile = $_POST['img_profile'];
$name = $_POST['name'];
$email = $_POST['email'];
$tel = $_POST['tel'];
$gender = $_POST['gender'];
$password = intval($_POST['password']); // รับรหัสผ่านธรรมดาจาก Flutter
$img_id_card = $_POST['img_id_card'];
$img_driver_license = $_POST['img_driver_license'];
$img_car_picture = $_POST['img_car_picture'];
$img_car_registration = $_POST['img_car_registration'];
$img_act = $_POST['img_act'];
$expiration_date = $_POST['expiration_date'];
$car_registration = $_POST['car_rigistration']; // spelling ตามฐานข้อมูล
$car_brand = $_POST['car_brand'];
$bank = $_POST['bank'];
$name_account = $_POST['name_account'];
$number_bank = intval($_POST['number_bank']);
$status_rider = intval($_POST['status_rider']);
$reason = $_POST['reason'];

// แฮชรหัสผ่านก่อนบันทึก
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// เตรียมคำสั่ง SQL สำหรับการ INSERT
$stmt = $conn->prepare("
    INSERT INTO `table_rider` 
    (`img_profile`, `name`, `email`, `tel`, `gender`, `password`, `img_id_card`, `img_driver_license`, `img_car_picture`, `img_car_registration`, `img_act`, `expiration_date`, `car_rigistration`, `car_brand`, `bank`, `name_account`, `number_bank`, `status_rider`, `reason`) 
    VALUES 
    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "sssssssssssssssssss",
    $img_profile,
    $name,
    $email,
    $tel,
    $gender,
    $hashed_password, // ใช้รหัสผ่านที่แฮชแล้ว
    $img_id_card,
    $img_driver_license,
    $img_car_picture,
    $img_car_registration,
    $img_act,
    $expiration_date,
    $car_registration,
    $car_brand,
    $bank,
    $name_account,
    $number_bank,
    $status_rider,
    $reason
);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Insert Success"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

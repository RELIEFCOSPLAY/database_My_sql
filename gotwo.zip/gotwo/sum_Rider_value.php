<?php
// เชื่อมต่อกับฐานข้อมูล
header('Content-Type: application/json; charset=utf-8');
include("config.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $rider_id = $_POST['userid'];
    // $rider_id = 22;
    $sql = "SELECT SUM(price) AS sum_price FROM post WHERE rider_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $rider_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // แสดงผลลัพธ์
        $row = $result->fetch_assoc();
        $sum_price = (int) round($row['sum_price']);
        // echo "Sum Price (rounded): " . $sum_price;
        echo json_encode([
            'success' => true,
            'sum_price' => (int)$sum_price, // บังคับให้เป็น int
        ]);
    } else {
        echo "No data found.";
    }

    // ปิดการเชื่อมต่อ
    $conn->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
}

<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php"); // รวมไฟล์ config.php เพื่อเชื่อมต่อกับฐานข้อมูล

$sql = "SELECT * FROM table_customer"; // ดึงข้อมูลจากตาราง status_post
$result = mysqli_query($conn, $sql);

$response = array(); // สร้าง array เพื่อเก็บผลลัพธ์

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // เพิ่มข้อมูลแต่ละแถวลงใน response
        array_push($response, $row);
    }
} else {
    // กรณีไม่มีข้อมูลในฐานข้อมูล
    $response['message'] = "No data found.";
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); 
mysqli_close($conn);
?>

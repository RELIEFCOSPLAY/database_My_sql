<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // โฟลเดอร์ที่เก็บไฟล์ต้นฉบับ
    $targetDir1 = "uploads/";

    // โฟลเดอร์เป้าหมายใหม่
    $targetDir2 = "D:/Gotwo/GOTWO/public/gotwo_app/gotwo/uploads/";

    // สร้างโฟลเดอร์ถ้ายังไม่มี
    if (!is_dir($targetDir1)) {
        mkdir($targetDir1, 0777, true);
    }
    if (!is_dir($targetDir2)) {
        mkdir($targetDir2, 0777, true);
    }

    // ชื่อไฟล์ต้นฉบับ
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath1 = $targetDir1 . $fileName;
    $targetFilePath2 = $targetDir2 . $fileName;

    // ตรวจสอบและย้ายไฟล์ไปยังทั้งสองตำแหน่ง
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath1)) {
        // คัดลอกไฟล์ไปยังตำแหน่งที่สอง
        if (copy($targetFilePath1, $targetFilePath2)) {
            $fileUrl = "gotwo/uploads/" . $fileName; // URL ไฟล์สำหรับตำแหน่งเดิม

            echo json_encode([
                "message" => "File uploaded successfully to both locations",
                "file" => $fileUrl, // URL ตำแหน่งเดิม
                // "file2" => $targetDir2 . $fileName // ตำแหน่งที่เก็บไฟล์ใหม่
            ]);
        } else {
            echo json_encode([
                "error" => "File uploaded to first location but failed to copy to second location"
            ]);
        }
    } else {
        echo json_encode(["error" => "File upload failed"]);
    }
} else {
    echo json_encode(["error" => "Invalid request"]);
}
?>

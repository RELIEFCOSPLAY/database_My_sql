<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php");

function saveImage($base64Img, $path, $filename) {
    $decodedImg = base64_decode($base64Img);
    $filepath = $path . $filename;
    if (file_put_contents($filepath, $decodedImg)) {
        return $filepath; // ส่งพาธของไฟล์กลับ
    }
    return null; // ถ้าบันทึกไม่สำเร็จ
}

// รับค่าที่ส่งมาจาก Flutter
$img_profile_base64 = $_POST['img_profile'];
$name = $_POST['name'];
$email = $_POST['email'];
$tel = $_POST['tel'];
$gender = $_POST['gender'];
$password = $_POST['password'];
$img_id_card_base64 = $_POST['img_id_card'];
$img_driver_license_base64 = $_POST['img_driver_license'];
$img_car_picture_base64 = $_POST['img_car_picture'];
$img_car_registration_base64 = $_POST['img_car_registration'];
$img_act_base64 = $_POST['img_act'];
$expiration_date = $_POST['expiration_date'];
$car_registration = $_POST['car_rigistration'];
$car_brand = $_POST['car_brand'];
$bank = $_POST['bank'];
$name_account = $_POST['name_account'];
$number_bank = intval($_POST['number_bank']);
$status_rider = intval($_POST['status_rider']);
$reason = $_POST['reason'];

// บันทึกรูปภาพในเซิร์ฟเวอร์
$uploadDir = "uploads/";
$imgProfilePath = saveImage($img_profile_base64, $uploadDir, "profile_" . time() . ".jpg");
$imgIdCardPath = saveImage($img_id_card_base64, $uploadDir, "idcard_" . time() . ".jpg");
$imgDriverLicensePath = saveImage($img_driver_license_base64, $uploadDir, "license_" . time() . ".jpg");
$imgCarPicturePath = saveImage($img_car_picture_base64, $uploadDir, "car_" . time() . ".jpg");
$imgCarRegistrationPath = saveImage($img_car_registration_base64, $uploadDir, "registration_" . time() . ".jpg");
$imgActPath = saveImage($img_act_base64, $uploadDir, "act_" . time() . ".jpg");

// ตรวจสอบว่าบันทึกรูปภาพสำเร็จหรือไม่
if (!$imgProfilePath || !$imgIdCardPath || !$imgDriverLicensePath || !$imgCarPicturePath || !$imgCarRegistrationPath || !$imgActPath) {
    echo json_encode(["status" => "error", "message" => "Failed to save images."]);
    exit();
}

// เตรียมคำสั่ง SQL สำหรับการ INSERT
$sql = "INSERT INTO `table_rider` 
        (`img_profile`, `name`, `email`, `tel`, `gender`, `password`, `img_id_card`, `img_driver_license`, `img_car_picture`, `img_car_registration`, `img_act`, `expiration_date`, `car_rigistration`, `car_brand`, `bank`, `name_account`, `number_bank`, `status_rider`, `reason`) 
        VALUES 
        ('$imgProfilePath', '$name', '$email', '$tel', '$gender', '$password', '$imgIdCardPath', '$imgDriverLicensePath', '$imgCarPicturePath', '$imgCarRegistrationPath', '$imgActPath', '$expiration_date', '$car_registration', '$car_brand', '$bank', '$name_account', '$number_bank', '$status_rider', '$reason')";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success", "message" => "Insert success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error inserting data"]);
}

?>

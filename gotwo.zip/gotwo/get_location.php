<?php
header('Content-Type: application/json; charset=utf-8');
include("config.php");

// สร้างคำสั่ง SQL
$sql = "SELECT LocationID, LocationList FROM location_list";

$result = mysqli_query($conn, $sql);

$response = array();

// ตรวจสอบว่ามีข้อมูลในฐานข้อมูลหรือไม่
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $location = array();
        $location["LocationID"] = $row['LocationID'];
        $location["LocationList"] = $row['LocationList'];

        array_push($response, $location);
    }
} else {
    $response["error"] = "No data found.";
}

// ส่งข้อมูล JSON กลับไปยัง Flutter
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
mysqli_close($conn);

?>
